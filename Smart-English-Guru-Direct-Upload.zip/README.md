# Smart English Guru — Direct Upload Edition

ही एक single-file web app आहे.

## Upload
फक्त `index.html` GitHub repository मध्ये upload करा.

## GitHub Pages
Settings → Pages → Deploy from a branch → main → /(root) → Save

## Features
- 40 textbook-level topics
- Types and sub-types
- Rules and examples
- English/Marathi pronunciation
- 20 MCQs per topic
- Score and restart
- Topic search
- A+ / A- font controls
- Dark mode
- Mobile responsive
- No external libraries required
- Offline-friendly
